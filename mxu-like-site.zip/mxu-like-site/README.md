
# Academic Personal Site (Original Template)

- Plain HTML/CSS, works out-of-the-box on GitHub Pages (no build step).
- Sections: About, Research Interests, Publications, Talks, Services, Teaching, Awards, Contact.

## How to Use
1. Create a repo named `USERNAME.github.io` (Public).
2. Upload all files at repository root.
3. Edit `index.html` to replace with your info.
4. Replace `assets/avatar.png` with your photo (keep the filename).
